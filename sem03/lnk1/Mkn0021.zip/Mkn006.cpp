#include <iostream>

using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    int size;

    LinkedList() {
        head = nullptr;
        size = 0;
    }

    void insert(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }temp->next = newNode;
        }size++;
    }
    void insertAtMiddle(int pos,int value){
        Node* newNode = new Node(value);
        Node* mid = head;
        while(pos-1){
            mid = mid->next;
            pos--;
        }newNode->next = mid->next;
            mid->next = newNode;
            size++;
    }

    void display() {
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }cout << endl;
    }
};

int main() {
    LinkedList list;
    cout<<"Enter the size of the linkedList : ";
    int n,a,pos; cin>>n;
    cout << "Enter " << n << " elements: ";
    for (int i = 1; i <= n; i++) {
        cin >> a;
        list.insert(a);
    }
    cout << "Enter the position where you want to insert: ";
    cin >> pos;
    if(pos>list.size){
        cout<<"Invalid Position !!";
        return 0;
    }cout << "Enter the element you want to insert at position " << pos << ": ";

    cin>>a; list.insertAtMiddle(pos,a);
    list.display();

    return 0;
}

